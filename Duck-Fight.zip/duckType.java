 public enum duckType
  {
    Mallard, Pintail, Rubber
  }
  //duckTypes